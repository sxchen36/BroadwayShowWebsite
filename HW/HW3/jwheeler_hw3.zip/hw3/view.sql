CREATE VIEW erics
AS SELECT * FROM Student where fname = 'eric';
